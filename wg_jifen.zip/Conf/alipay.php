<?php 
return array (
  'pay_type' => 'alipay',
  'tenpay_partnerid' => '',
  'tenpay_partnerkey' => '',
  'alipay_name' => '123456@123.123',
  'alipay_pid' => '123456789',
  'alipay_key' => '123asdasdasdas12d3as1d',
);