<?php 
return array (
  'sms_url' => '',
  'sms_key' => 'key',
  'sms_price' => '8',
);