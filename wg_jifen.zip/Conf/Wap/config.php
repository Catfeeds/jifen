<?php
return array(
	'TMPL_FILE_DEPR'=>'_',
	'DEFAULT_THEME'=>'default',
	'TMPL_ACTION_ERROR' => THINK_PATH . 'tpl/wap_jump.tpl',
	'TMPL_ACTION_SUCCESS' => THINK_PATH . 'tpl/wap_jump.tpl',
);