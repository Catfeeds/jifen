<?php
return array (
  'DB_TYPE' => 'mysql',
  'DB_HOST' => 'localhost',
  'DB_PORT' => '3306',
  'DB_NAME' => 'jifen_data',
  'DB_USER' => 'root',
  'DB_PWD' => 'root',
  'DB_PREFIX' => 'pigcms_',
);
?>