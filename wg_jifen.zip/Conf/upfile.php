<?php 
return array (
  'upload_type' => 'local',
  'up_bucket' => 'hmpic',
  'up_form_api_secret' => 'zpSko3gVNCu6G/um7CUuft9ukWs=',
  'up_username' => 'hmpic',
  'up_password' => 'KxYmhm5p',
  'up_domainname' => 'hmpic.b0.upaiyun.com',
  'up_exts' => 'jpeg,jpg,png,gif',
  'up_size' => '2048',
  'up_path' => './data/upload',
  'connectnum' => '系统维护中',
);